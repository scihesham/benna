
<html>
<head>
    <title>تحت الصيانه</title>
</head>
<body>
    <div style="width:100%; text-align:center; padding-top:50px; padding-bottom:50px">
        <img src="{{url('public/design/mandoby/images/underconstruction.png')}}" />
    </div>
</body>
</html>