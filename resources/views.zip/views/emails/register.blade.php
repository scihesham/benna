<!DOCTYPE html>
<html>

<head>
    <style>
        table{margin-top: 50px}
        table, td, th{border: 1px solid #EEE;}
        td, th{padding: 20px}
    </style>
</head>

<body>
    <center>
        <h2> تم انشاء حساب جديد لدى  <span style="color:#22a1ff !important">بناء كويك</span> </h2>
    </center>
    <div style="width:90%; margin:0 auto; text-align:right">
        <h3>من فضلك قم بالضغط فوق هذا <a href="{{url('code').'/'.$elink}}">الرابط</a> 
            لتفعيل حسابك
        </h3>
    </div>
</body>

</html>
