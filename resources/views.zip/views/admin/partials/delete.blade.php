{{-- delete --}}
<div class="alert alert-danger error_delete_msg  hidden text-center"></div>
<div class="alert alert-success success_delete_msg hidden text-center"></div>

