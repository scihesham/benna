<div class="loading">
    <div></div>
    <div></div>
    <div></div>
</div>