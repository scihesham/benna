<!--<body class="hold-transition skin-blue sidebar-mini">-->

<body class="hold-transition skin-purple-light	
 sidebar-mini">