<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; <span class="copyright_date">2014-2016</span> <a href="#">بناء كويك</a>.</strong> All rights
    reserved.
</footer>