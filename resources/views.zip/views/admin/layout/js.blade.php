<!-- jQuery 3 -->
<script src="{{asset('public/design/adminlte/plugins/jquery/dist/jquery.min.js')}}"></script>
<!-- Bootstrap 3.3.7 -->
<script src="{{asset('public/design/adminlte/plugins/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- SlimScroll -->
<script src="{{asset('public/design/adminlte/plugins/jquery-slimscroll/jquery.slimscroll.min.js')}}"></script>
<!-- FastClick -->
<script src="{{asset('public/design/adminlte/plugins/fastclick/lib/fastclick.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{asset('public/design/adminlte/dist/js/adminlte.min.js')}}"></script>

<script src="{{url('public/design/adminlte')}}/dist/js/jquery-ui.min.js"></script>
<script src="{{url('public/design/adminlte')}}/dist/js/jquery.selectBoxIt.min.js"></script>
<script src="{{url('public/design/adminlte')}}/dist/js/backend.js"></script>


{{--<script src="{{asset('public/design/adminlte/plugins/iCheck/icheck.min.js')}}"></script>--}}

{{--<script>--}}

    {{--$(function () {--}}
        {{--//Enable iCheck plugin for checkboxes--}}
        {{--//iCheck for checkbox and radio inputs--}}
        {{--$('.mailbox-messages input[type="checkbox"]').iCheck({--}}
            {{--checkboxClass: 'icheckbox_flat-blue',--}}
            {{--radioClass: 'iradio_flat-blue'--}}
        {{--});--}}

        {{--//Enable check and uncheck all functionality--}}
        {{--$(".checkbox-toggle").click(function () {--}}
            {{--var clicks = $(this).data('clicks');--}}
            {{--if (clicks) {--}}
                {{--//Uncheck all checkboxes--}}
                {{--$(".mailbox-messages input[type='checkbox']").iCheck("uncheck");--}}
                {{--$(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');--}}
            {{--} else {--}}
                {{--//Check all checkboxes--}}
                {{--$(".mailbox-messages input[type='checkbox']").iCheck("check");--}}
                {{--$(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');--}}
            {{--}--}}
            {{--$(this).data("clicks", !clicks);--}}
        {{--});--}}

        {{--//Handle starring for glyphicon and font awesome--}}
        {{--$(".mailbox-star").click(function (e) {--}}
            {{--e.preventDefault();--}}
            {{--//detect type--}}
            {{--var $this = $(this).find("a > i");--}}
            {{--var glyph = $this.hasClass("glyphicon");--}}
            {{--var fa = $this.hasClass("fa");--}}

            {{--//Switch states--}}
            {{--if (glyph) {--}}
                {{--$this.toggleClass("glyphicon-star");--}}
                {{--$this.toggleClass("glyphicon-star-empty");--}}
            {{--}--}}

            {{--if (fa) {--}}
                {{--$this.toggleClass("fa-star");--}}
                {{--$this.toggleClass("fa-star-o");--}}
            {{--}--}}
        {{--});--}}
    {{--});--}}
{{--</script>--}}

<!-- AdminLTE for demo purposes -->
<script src="{{asset('public/design/adminlte/dist/js/demo.js')}}"></script>

<script src="{{asset('public/design/adminlte/main.js')}}"></script>
<script>
    $(document).ready(function () {
        $('.sidebar-menu').tree()
    })
</script>