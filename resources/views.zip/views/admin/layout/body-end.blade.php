@yield('footer')
<script src="{{url('public/design/adminlte')}}/dist/js/notification.js"></script>
</body>
</html>