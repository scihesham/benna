

<a href="{{url('register?action=institute#institute')}}">
<div class="col-sm-3 text-center" id="institute" data-class="data-4">مؤسسه</div>
</a>

<a href="{{url('register?action=company#company')}}">
<div class="col-sm-3 text-center" id="company" data-class="data-3">شركه </div>
</a>
<a href="{{url('register?action=personal#personal')}}">
<div class="col-sm-3 text-center" id="personal" data-class="data-2">شخصي </div>
</a>
<a href="{{url('register?action=owner#owner')}}">
<div class="col-sm-3 text-center selected" id="owner" data-class="data-1">صاحب مشروع</div>
</a>

<br>